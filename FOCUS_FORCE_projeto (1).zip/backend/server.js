const express = require("express");
const app = express();
app.use(express.json({ limit: "20kb" }));

// Configure OPENAI_API_KEY as a server environment variable.
// Never commit .env or put the key in the Android app.
app.post("/chat", async (req, res) => {
  try {
    const message = String(req.body.message || "").slice(0, 4000);
    if (!message) return res.status(400).json({ error: "Mensagem vazia" });
    if (!process.env.OPENAI_API_KEY) return res.status(503).json({ error: "IA ainda não configurada" });
    const response = await fetch(process.env.AI_API_URL || "https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: { "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: process.env.AI_MODEL || "gpt-4o-mini",
        messages: [
          { role: "system", content: "Você é a Focus AI, uma assistente responsável de hábitos saudáveis, organização e foco. Não incentive excesso de exercícios, dietas restritivas ou práticas perigosas. Oriente a procurar um profissional quando apropriado." },
          { role: "user", content: message }
        ]
      })
    });
    const data = await response.json();
    if (!response.ok) return res.status(502).json({ error: "Falha no provedor de IA" });
    res.json({ reply: data.choices?.[0]?.message?.content || "Sem resposta." });
  } catch (e) { res.status(500).json({ error: "Erro interno" }); }
});
const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Focus AI server on ${port}`));
