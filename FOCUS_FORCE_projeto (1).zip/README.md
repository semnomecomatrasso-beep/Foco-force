# FOCUS FORCE

Projeto inicial Android (Java) + servidor separado para a Focus AI.

## Gerar APK pelo GitHub
1. Envie o conteúdo deste ZIP para um repositório GitHub.
2. Copie `.github/workflows/build.yml` para o repositório (ou mantenha-o neste projeto).
3. Abra **Actions** e execute **Build APK**.
4. O APK de debug será publicado como artefato da execução.

## Publicar em Releases
Crie e envie uma tag, por exemplo:
`git tag v1.0.0 && git push origin v1.0.0`
O workflow `release.yml` compila o APK e cria uma GitHub Release.

## Focus AI com segurança
- Implante a pasta `backend` em um servidor Node.js.
- Configure `OPENAI_API_KEY` nas variáveis secretas do serviço de hospedagem.
- Configure `AI_API_URL` e `AI_MODEL` conforme seu provedor.
- Edite `AI_SERVER_URL` em `MainActivity.java` para apontar para `https://SEU-DOMINIO/chat`.
- A chave nunca deve ser colocada no APK, no GitHub ou protegida por uma senha dentro do app. Tudo que vai dentro do APK pode ser extraído.
- Revogue a chave que foi compartilhada na conversa e crie outra.

## Estado deste projeto
Este é um ponto de partida funcional com navegação básica, perfil local, registro simples de treino, temporizador de foco e cliente da IA via backend. Login, sincronização em nuvem, notificações exatas, câmera/repetições e rastreamento avançado ainda precisam ser implementados antes de chamar o app de completo.
