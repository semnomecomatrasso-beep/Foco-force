package com.focusforce.app;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.content.*;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.*;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(7, 7, 15), purple = Color.rgb(174, 0, 255), blue = Color.rgb(0, 145, 255);
    private LinearLayout root, content;
    private TextView timerText;
    private Handler handler = new Handler();
    private int seconds = 1500;
    private boolean running = false;
    private Runnable ticker;
    // Configure this with your deployed backend URL. Never put an AI secret/API key here.
    private static final String AI_SERVER_URL = "https://SEU-SERVIDOR.example.com/chat";

    @Override public void onCreate(Bundle b) { super.onCreate(b); showHome(); }

    private TextView text(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setPadding(12, 10, 12, 10); return t;
    }
    private Button button(String s, Runnable action) {
        Button b = new Button(this); b.setText(s); b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(purple));
        b.setOnClickListener(v -> action.run()); return b;
    }
    private void page(String title) {
        root = new LinearLayout(this); root.setOrientation(1); root.setBackgroundColor(bg);
        root.setPadding(18, 24, 18, 12); setContentView(root);
        TextView logo = text("♛  FOCUS FORCE", 25, Color.WHITE); logo.setTypeface(null, Typeface.BOLD);
        root.addView(logo); root.addView(text(title, 23, purple));
        ScrollView scroll = new ScrollView(this); content = new LinearLayout(this); content.setOrientation(1);
        scroll.addView(content); root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        LinearLayout nav = new LinearLayout(this); nav.setGravity(Gravity.CENTER);
        String[] tabs = {"Início","Treino","Foco","Focus AI","Perfil"};
        for (String tab : tabs) {
            Button b = new Button(this); b.setText(tab); b.setTextSize(10);
            b.setOnClickListener(v -> { if(tab.equals("Início")) showHome(); else if(tab.equals("Treino")) showWorkout(); else if(tab.equals("Foco")) showFocus(); else if(tab.equals("Focus AI")) showAI(); else showProfile(); });
            nav.addView(b, new LinearLayout.LayoutParams(0, -2, 1));
        }
        root.addView(nav);
    }
    private void card(String title, String desc) {
        TextView v = text(title + "\n" + desc, 16, Color.WHITE);
        v.setBackgroundColor(Color.rgb(25, 20, 42)); v.setPadding(18,18,18,18);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,8,0,8); content.addView(v,p);
    }
    private void showHome() {
        page("Seu próximo nível começa hoje");
        String name = getPreferences(0).getString("name", "Atleta");
        card("Olá, " + name + "!", "Treine seu corpo, fortaleça sua mente.");
        card("Sequência ativa", getPreferences(0).getInt("days",0) + " dias • descanso também faz parte da evolução");
        card("Missão de hoje", "Escolha uma atividade saudável e conclua no seu ritmo.");
        content.addView(button("COMEÇAR TREINO", this::showWorkout));
        content.addView(button("INICIAR FOCO", this::showFocus));
    }
    private void showWorkout() {
        page("Treino");
        card("Aquecimento", "Comece com movimentos leves e confortáveis.");
        String[] exercises = {"Agachamento livre — 2 séries leves","Flexão adaptada — escolha uma variação confortável","Ponte de glúteos — movimento controlado","Alongamento leve — sem forçar"};
        for(String e:exercises) card(e, "Priorize a técnica. Pare se sentir dor ou mal-estar.");
        content.addView(button("MARCAR SESSÃO CONCLUÍDA", () -> {
            getPreferences(0).edit().putInt("workouts", getPreferences(0).getInt("workouts",0)+1).apply();
            Toast.makeText(this,"Sessão registrada!",Toast.LENGTH_SHORT).show(); showHome();
        }));
    }
    private void showFocus() {
        page("Modo Foco");
        timerText = text(format(seconds), 42, blue); timerText.setGravity(Gravity.CENTER); content.addView(timerText);
        content.addView(button(running ? "PAUSAR" : "INICIAR 25 MIN", () -> toggleTimer()));
        content.addView(button("REINICIAR", () -> { running=false; seconds=1500; showFocus(); }));
        card("Dica", "Escolha uma tarefa pequena. Faça uma pausa quando terminar.");
    }
    private String format(int s) { return String.format("%02d:%02d", s/60, s%60); }
    private void toggleTimer() {
        if(running) { running=false; handler.removeCallbacks(ticker); showFocus(); return; }
        running=true;
        ticker = new Runnable() { public void run() {
            if(!running) return;
            if(seconds>0) { seconds--; if(timerText!=null) timerText.setText(format(seconds)); handler.postDelayed(this,1000); }
            else { running=false; Toast.makeText(MainActivity.this,"Sessão concluída. Boa!",Toast.LENGTH_LONG).show(); }
        }};
        handler.post(ticker);
        // refresh control label without resetting the timer
        Toast.makeText(this,"Foco iniciado!",Toast.LENGTH_SHORT).show();
    }
    private void showAI() {
        page("Focus AI");
        card("Assistente", "Converse com sua assistente para organizar hábitos, foco e atividades.");
        EditText input = new EditText(this); input.setHint("Escreva sua pergunta…"); input.setTextColor(Color.WHITE); input.setHintTextColor(Color.LTGRAY);
        content.addView(input);
        TextView answer = text("As respostas serão exibidas aqui.",14,Color.WHITE); content.addView(answer);
        content.addView(button("ENVIAR", () -> {
            String q=input.getText().toString().trim();
            if(q.isEmpty()) { answer.setText("Escreva uma pergunta primeiro."); return; }
            answer.setText("Conectando à Focus AI…");
            new Thread(() -> {
                try {
                    JSONObject body=new JSONObject(); body.put("message",q);
                    URL url=new URL(AI_SERVER_URL); HttpURLConnection c=(HttpURLConnection)url.openConnection();
                    c.setRequestMethod("POST"); c.setConnectTimeout(15000); c.setReadTimeout(30000);
                    c.setDoOutput(true); c.setRequestProperty("Content-Type","application/json");
                    try(OutputStream os=c.getOutputStream()){ os.write(body.toString().getBytes("UTF-8")); }
                    InputStream is=(c.getResponseCode()<400)?c.getInputStream():c.getErrorStream();
                    ByteArrayOutputStream out=new ByteArrayOutputStream(); byte[] buf=new byte[1024]; int n;
                    while((n=is.read(buf))!=-1) out.write(buf,0,n);
                    JSONObject result=new JSONObject(out.toString("UTF-8"));
                    String reply=result.optString("reply","Não foi possível obter uma resposta.");
                    runOnUiThread(() -> answer.setText(reply)); c.disconnect();
                } catch(Exception ex) { runOnUiThread(() -> answer.setText("Não foi possível conectar. Configure a URL do servidor e verifique a conexão.")); }
            }).start();
        }));
        card("Privacidade", "A conversa é enviada ao seu servidor de IA. Não coloque senhas ou dados sensíveis.");
    }
    private void showProfile() {
        page("Perfil");
        EditText name = new EditText(this); name.setSingleLine(); name.setHint("Seu nome");
        name.setText(getPreferences(0).getString("name","")); name.setTextColor(Color.WHITE); content.addView(name);
        content.addView(button("SALVAR PERFIL", () -> {
            getPreferences(0).edit().putString("name",name.getText().toString().trim()).apply();
            Toast.makeText(this,"Perfil salvo!",Toast.LENGTH_SHORT).show(); showHome();
        }));
        card("Estatísticas", "Treinos registrados: " + getPreferences(0).getInt("workouts",0));
        card("Dados", "Este protótipo salva o perfil localmente neste aparelho. Sincronização e login exigem backend.");
    }
    @Override protected void onDestroy() { super.onDestroy(); running=false; handler.removeCallbacksAndMessages(null); }
}
